while ($true)
{
	\iotedge\log-sec 30
	iotedge list
    	sleep 29
}