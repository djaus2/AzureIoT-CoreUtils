\iotedge\uninstall
Get-Content -Path c:\iotedge\cs.txt | \iotedge\install