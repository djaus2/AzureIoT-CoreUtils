Stop-Service iotedge -NoWait
sleep 5
Start-Service iotedge