\iotedge\uninstall
\iotedge\install