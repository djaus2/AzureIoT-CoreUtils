while ($true)
{
	\iotedge\logsec 30
	iotedge list
    	sleep 29
}